Este archivo no es imagen
